sudo mv Ccany /usr/local
cd /usr/local/Ccany
sudo mv Ccany /usr/local/bin
cd /usr/local/Ccany
sudo mv Ccany.desktop /usr/share/applications
echo "O Aplicativo C&cany++ foi instalado com sucesso!"
echo "*para modificar a biblioteca de consulta acesse /usr/local/Ccany/libCcany"
echo "pressione qualquer tecla para finalizar"
read esc
cd
sudo rm -r instaladorCcany
