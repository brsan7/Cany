/*
 * File:   gui_Ccani.cpp
 * Author: Bruno Santos
 *
 * Created on 14 de Janeiro de 2020, 14:14
 */

#include "gui_Ccany.h"
#include "navegador.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char menu[1000],atualMenu[100],atualPasta[100];
char pastasRaiz[1000];
char arquivosSelecao[1000];
int indexRaiz=0,indexArquivos=0;
gui_Ccany::gui_Ccany() {
    widget.setupUi(this);
    widget.comboBox->insertItem(0,"           Canivete Universal");
    char tmpPastas[7007]="\0";
    int indicePastas=0,indiceComboBox=1;
    listarRaiz();
    while(strcspn(pastasRaiz,"\n")!=NULL){
        char pastaAtual[100]="\0",itemComboBox[100]="\0";
        strcpy(tmpPastas,&pastasRaiz[indicePastas]);
        strcpy(pastasRaiz,tmpPastas);
        indicePastas=strcspn(pastasRaiz,"\n");
        strncpy(pastaAtual,pastasRaiz,indicePastas);
        if(strcspn(pastasRaiz,"\n")!=NULL){
            indiceComboBox++;indicePastas++;
            widget.textEdit->append("_______________________________________________");
            widget.textEdit->append(pastaAtual);
            listarSelecao(pastaAtual);
            widget.textEdit->append(enfileirar(arquivosSelecao,pastaAtual,"h"));
            widget.textEdit->append(arquivosSelecao);
            widget.textEdit->append("_______________________________________________");
            if(strlen(pastaAtual)<39){
                memset(itemComboBox,'_',(40-strlen(pastaAtual))/2);
                strcat(itemComboBox,pastaAtual);
                div_t n=div((40-strlen(pastaAtual)),2);
                if(n.rem!=0){memset(&itemComboBox[strlen(itemComboBox)],'_',((40-strlen(pastaAtual))/2)+1);}
                else{memset(&itemComboBox[strlen(itemComboBox)],'_',(40-strlen(pastaAtual))/2);}
                widget.comboBox->insertItem(indiceComboBox,itemComboBox);
            }else{widget.comboBox->insertItem(indiceComboBox,pastaAtual);}
            strcat(menu,pastaAtual);
            strcat(menu," ");
        }indexRaiz=indiceComboBox;
        
    }
    connect(widget.comboBox, SIGNAL(currentIndexChanged(int)),
             this, SLOT(currentIndexChanged(int)));
}

gui_Ccany::~gui_Ccany() {
}

void gui_Ccany::currentIndexChanged(int index) {
    
    if(index==0){
        int indexDel=indexRaiz;
        indexDel+=indexArquivos;
        while(indexDel>0){
            widget.comboBox->removeItem(indexDel);
            indexDel--;
        }
        widget.textEdit->setText("");
        widget.comboBox->setItemText(0,"           Canivete Universal");
        char tmpPastas[7007]="\0";
        int indicePastas=0,indiceComboBox=1;
        listarRaiz();
        memset(menu,'\0',1000);
        while(strcspn(pastasRaiz,"\n")!=NULL){
            char pastaAtual[100]="\0",itemComboBox[100]="\0";
            strcpy(tmpPastas,&pastasRaiz[indicePastas]);
            strcpy(pastasRaiz,tmpPastas);
            indicePastas=strcspn(pastasRaiz,"\n");
            strncpy(pastaAtual,pastasRaiz,indicePastas);
            if(strcspn(pastasRaiz,"\n")!=NULL){
                indiceComboBox++;indicePastas++;
                widget.textEdit->append("_______________________________________________");
                widget.textEdit->append(pastaAtual);
                listarSelecao(pastaAtual);
                widget.textEdit->append(enfileirar(arquivosSelecao,pastaAtual,"h"));
                widget.textEdit->append(arquivosSelecao);
                widget.textEdit->append("_______________________________________________");
                if(strlen(pastaAtual)<39){
                    memset(itemComboBox,'_',(40-strlen(pastaAtual))/2);
                    strcat(itemComboBox,pastaAtual);
                    div_t n=div((40-strlen(pastaAtual)),2);
                    if(n.rem!=0){memset(&itemComboBox[strlen(itemComboBox)],'_',((40-strlen(pastaAtual))/2)+1);}
                    else{memset(&itemComboBox[strlen(itemComboBox)],'_',(40-strlen(pastaAtual))/2);}
                    widget.comboBox->insertItem(indiceComboBox,itemComboBox);
                }else{widget.comboBox->insertItem(indiceComboBox,pastaAtual);}
                strcat(menu,pastaAtual);
                strcat(menu," ");
            }indexRaiz=indiceComboBox;
            
        }
    }
    else{
        widget.comboBox->setItemText(0,"<<<[Indice Geral]");
        if(index<indexRaiz){
            int indexDel=indexArquivos;
            while(indexDel>=indexRaiz){
                widget.comboBox->removeItem(indexDel);
                indexDel--;
            }
            
            indexDel=indexRaiz;
            IDatualMenu(menu,index);
            memset(atualPasta,'\0',100);
            strcpy(atualPasta,atualMenu);
            listarSelecao(atualMenu);
            widget.textEdit->setText(enfileirar(arquivosSelecao,atualMenu,"i"));
            int indiceArquivos=0,incremental=0;
            indexArquivos=indexRaiz;
            while(strcspn(&arquivosSelecao[indiceArquivos],"\n")!=NULL){
                char item[100]="\0";
                incremental=strcspn(&arquivosSelecao[indiceArquivos]," ");
                strncpy(item,&arquivosSelecao[indiceArquivos],incremental);
                widget.comboBox->insertItem(indexArquivos++,item);
                indiceArquivos+=incremental+1;
            }
            
            
        }
        if(index>=indexRaiz){
            int iD=index,id=indexRaiz;
            iD-=id;iD++;
            IDatualMenu(arquivosSelecao,iD);
            FILE *fp;
            char comando[200]="/usr/local/Ccany/libCcany/";
            strcat(comando,atualPasta);
            strcat(comando,"/");
            strcat(comando,atualMenu);
            if((fp=fopen(comando,"rb"))==NULL){printf("gui_Ccany.cpp:[136]\n");}
            char *arquivo="\0"; 
            unsigned int tamanho=0;
            while(!feof(fp)){getc(fp);tamanho++;}
            rewind(fp);
            if( (arquivo = (char*)malloc(tamanho) )==NULL) {
                printf("Erro de alocação - abortando.");
                exit(1);
            }
            fread(arquivo,(tamanho-3),1,fp);
            widget.textEdit->setText(arquivo);
            fclose(fp);
        }
    }
    
}
