/* 
 * File:   navegador.h
 * Author: Bruno Santos
 *
 * Created on 19 de Janeiro de 2020, 17:59
 */

#ifndef NAVEGADOR_H
#define	NAVEGADOR_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
extern char pastasRaiz[1000],arquivosSelecao[1000],atualMenu[100];

char listarRaiz(){
    FILE *fp;
    size_t tamanhoMax=7000;
    freopen("/usr/local/Ccany/tempCcany","w",stdout);
    system("ls /usr/local/Ccany/libCcany/");
    if((fp=fopen("/usr/local/Ccany/tempCcany","rb"))==NULL){printf("navegador:[21]\n");}
    fread(pastasRaiz,tamanhoMax,1,fp);
    fclose(fp);
    
}
char listarSelecao(char selecao[1000]){
    FILE *fp;
    size_t tamanhoMax=7000;
    char comando[100]="ls /usr/local/Ccany/libCcany/";
    memset(arquivosSelecao,'\0',1000);
    strcat(comando, selecao);
    freopen("/usr/local/Ccany/tempCcany","w",stdout);
    system(comando);
    if((fp=fopen("/usr/local/Ccany/tempCcany","rb"))==NULL){printf("navegador.h:[34]\n");}
    fread(arquivosSelecao,tamanhoMax,1,fp);
    fclose(fp);
    
}
char enfileirarBKP(char selecao[1000]){
    char saida[1000]="\0",ch[1];
    int indiceGeral=strlen(selecao),indiceP=0,indiceF=0;
    
    while(indiceGeral>strlen(saida)){
        strncpy(ch,&selecao[indiceF],1);
        if(isspace(*ch)!=0){
            indiceP=indiceF-strlen(saida);
            strncat(saida, &selecao[strlen(saida)],indiceP--);
            strcat(saida, " ");
        }
        indiceF++;
    }
    memset(arquivosSelecao,'\0',1000);
    strcpy(arquivosSelecao,saida);
}
char *enfileirar(char selecao[1000],char pasta[100],char id[1]){
    char saida[1000]="\0",tmpsaida[1000]="\0", *arquivo="\0";
    char ch[1],endereco[100]="/usr/local/Ccany/libCcany/";
    int indiceGeral=strlen(selecao),indiceP=0,indiceF=0,indiceEncontrado=0;
    while(indiceGeral>strlen(tmpsaida)){
        char verificador[100]="\0";
        strncpy(ch,&selecao[indiceF],1);
        if(isspace(*ch)!=0){
            indiceP=indiceF-strlen(tmpsaida);
            strncat(verificador, &selecao[strlen(tmpsaida)],indiceP--);
            strcat(tmpsaida, verificador);
            strcat(tmpsaida, " ");
            if(strcmp(verificador,"INDICE")!=0){
                strcat(saida,verificador);
                strcat(saida, " ");
            }
            else{
                indiceEncontrado++;
                strcat(endereco, pasta);
                strcat(endereco, "/");
                strcat(endereco, verificador);
                FILE *fp;
                if((fp=fopen(endereco,"rb"))==NULL){printf("navegador.h:[77]\n");}
                if(strcmp(id,"i")==0){
                unsigned int tamanho=0;
                while(!feof(fp)){getc(fp);tamanho++;}
                rewind(fp);
                if( (arquivo = (char*)malloc(tamanho) )==NULL) {
                    printf("Erro de alocação - abortando.");
                    exit(1);
                }
                fread(arquivo,(tamanho-3),1,fp);
                }
                if(strcmp(id,"h")==0){
                    if( (arquivo = (char*)malloc(200) )==NULL) {
                    printf("Erro de alocação - abortando.");
                    exit(1);
                    }
                    fgets(arquivo,200,fp);
                }
                fclose(fp);
                
            }
        }
        indiceF++;
    }
    if(indiceEncontrado==0&&strcmp(id,"i")==0){
        arquivo="Nao foi Encontrado o Arquivo INDICE\n\n";
    }
    if(indiceEncontrado==0&&strcmp(id,"h")==0){
        arquivo="\0";
    }
    memset(arquivosSelecao,'\0',1000);
    strcpy(arquivosSelecao,saida);
    return arquivo;
}
char IDatualMenu(char menu[100],int index){
    memset(atualMenu,'\0',100);
    int indiceMenu=0,INDEX=0;
    char tmpMenu[1000]="0",transfMenu[1000]="0";
    strcpy(tmpMenu,menu);
        while(INDEX!=index){
            char atMenu[100]="0";
            INDEX++;
            strcpy(transfMenu,&tmpMenu[indiceMenu]);
            strcpy(tmpMenu,transfMenu);
            indiceMenu=strcspn(tmpMenu," ");
            strncpy(atMenu,tmpMenu,indiceMenu);
            indiceMenu++;
            if(INDEX==index){strcpy(atualMenu,atMenu);}
        }
}

#endif	/* NAVEGADOR_H */

