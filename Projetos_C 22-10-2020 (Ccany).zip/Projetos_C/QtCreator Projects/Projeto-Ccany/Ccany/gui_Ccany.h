/* 
 * File:   gui_Ccani.h
 * Author: Bruno Santos
 *
 * Created on 14 de Janeiro de 2020, 16:14
 */

#ifndef _GUI_CCANI_H
#define	_GUI_CCANI_H

#include "ui_gui_Ccany.h"

class gui_Ccany : public QDialog {
    Q_OBJECT
public:
    gui_Ccany();
    virtual ~gui_Ccany();
public slots:
    void currentIndexChanged(int index);
    //void pageTitleChanged(const QString &title);
private:
    Ui::gui_Ccany widget;
};

#endif	/* _GUI_CCANI_H */
