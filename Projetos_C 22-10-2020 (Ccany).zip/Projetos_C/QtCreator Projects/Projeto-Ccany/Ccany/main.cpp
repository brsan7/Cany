/*
 * File:   main.cpp
 * Author: Bruno Santos
 *
 * Created on 14 de Janeiro de 2020, 16:14
 */

#include <QApplication>
#include "gui_Ccany.h"
int main(int argc, char *argv[]) {
    // initialize resources, if needed
    // Q_INIT_RESOURCE(resfile);

    QApplication app(argc, argv);

    // create and show your widgets here
    gui_Ccany form;
    form.show();
    return app.exec();
}
