/********************************************************************************
** Form generated from reading UI file 'gui_Ccany.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_CCANY_H
#define UI_GUI_CCANY_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_gui_Ccany
{
public:
    QTextEdit *textEdit;
    QComboBox *comboBox;

    void setupUi(QDialog *gui_Ccany)
    {
        if (gui_Ccany->objectName().isEmpty())
            gui_Ccany->setObjectName(QString::fromUtf8("gui_Ccany"));
        gui_Ccany->resize(400, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(gui_Ccany->sizePolicy().hasHeightForWidth());
        gui_Ccany->setSizePolicy(sizePolicy);
        gui_Ccany->setMinimumSize(QSize(400, 500));
        gui_Ccany->setMaximumSize(QSize(400, 500));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        gui_Ccany->setFont(font);
        textEdit = new QTextEdit(gui_Ccany);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(0, 0, 400, 470));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setWeight(50);
        textEdit->setFont(font1);
        textEdit->setLocale(QLocale(QLocale::Portuguese, QLocale::Brazil));
        textEdit->setInputMethodHints(Qt::ImhNone);
        textEdit->setReadOnly(true);
        comboBox = new QComboBox(gui_Ccany);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(0, 470, 400, 30));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Ubuntu Mono"));
        font2.setPointSize(14);
        font2.setBold(false);
        font2.setWeight(50);
        comboBox->setFont(font2);
        comboBox->setMaxVisibleItems(10);
        comboBox->setModelColumn(0);

        retranslateUi(gui_Ccany);

        QMetaObject::connectSlotsByName(gui_Ccany);
    } // setupUi

    void retranslateUi(QDialog *gui_Ccany)
    {
        gui_Ccany->setWindowTitle(QApplication::translate("gui_Ccany", "C&cany++", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gui_Ccany: public Ui_gui_Ccany {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_CCANY_H
