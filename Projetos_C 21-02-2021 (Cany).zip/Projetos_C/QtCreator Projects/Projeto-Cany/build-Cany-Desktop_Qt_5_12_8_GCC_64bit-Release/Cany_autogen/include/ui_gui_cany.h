/********************************************************************************
** Form generated from reading UI file 'gui_cany.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_CANY_H
#define UI_GUI_CANY_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gui_cany
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab_1;
    QComboBox *comboBox_1_1;
    QComboBox *comboBox_1_2;
    QComboBox *comboBox_1_3;
    QTextBrowser *textBrowser_1_1;
    QWidget *tab_2;
    QTextBrowser *textBrowser_2_1;
    QLabel *label_2_1;
    QLabel *label_2_2;
    QLabel *label_2_3;
    QComboBox *comboBox_2_1;
    QComboBox *comboBox_2_2;
    QTextBrowser *textBrowser_2_2;
    QTextBrowser *textBrowser_2_3;
    QLabel *label_2_4;
    QLabel *label_2_5;
    QLabel *label_2_6;
    QComboBox *comboBox_2_3;
    QPushButton *pushButton_2_1;
    QWidget *tab_3;
    QLabel *label_3_1;

    void setupUi(QDialog *gui_cany)
    {
        if (gui_cany->objectName().isEmpty())
            gui_cany->setObjectName(QString::fromUtf8("gui_cany"));
        gui_cany->resize(480, 700);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(gui_cany->sizePolicy().hasHeightForWidth());
        gui_cany->setSizePolicy(sizePolicy);
        gui_cany->setMinimumSize(QSize(204, 104));
        gui_cany->setMaximumSize(QSize(480, 700));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/cany.png"), QSize(), QIcon::Normal, QIcon::Off);
        gui_cany->setWindowIcon(icon);
        centralwidget = new QWidget(gui_cany);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setGeometry(QRect(0, 0, 480, 700));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 480, 700));
        tab_1 = new QWidget();
        tab_1->setObjectName(QString::fromUtf8("tab_1"));
        comboBox_1_1 = new QComboBox(tab_1);
        comboBox_1_1->setObjectName(QString::fromUtf8("comboBox_1_1"));
        comboBox_1_1->setGeometry(QRect(10, 550, 460, 30));
        comboBox_1_1->setEditable(false);
        comboBox_1_2 = new QComboBox(tab_1);
        comboBox_1_2->setObjectName(QString::fromUtf8("comboBox_1_2"));
        comboBox_1_2->setGeometry(QRect(10, 590, 460, 30));
        comboBox_1_3 = new QComboBox(tab_1);
        comboBox_1_3->setObjectName(QString::fromUtf8("comboBox_1_3"));
        comboBox_1_3->setGeometry(QRect(10, 630, 460, 30));
        textBrowser_1_1 = new QTextBrowser(tab_1);
        textBrowser_1_1->setObjectName(QString::fromUtf8("textBrowser_1_1"));
        textBrowser_1_1->setGeometry(QRect(10, 10, 460, 530));
        textBrowser_1_1->setAcceptRichText(false);
        tabWidget->addTab(tab_1, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        textBrowser_2_1 = new QTextBrowser(tab_2);
        textBrowser_2_1->setObjectName(QString::fromUtf8("textBrowser_2_1"));
        textBrowser_2_1->setGeometry(QRect(10, 110, 460, 100));
        textBrowser_2_1->setReadOnly(false);
        textBrowser_2_1->setAcceptRichText(false);
        label_2_1 = new QLabel(tab_2);
        label_2_1->setObjectName(QString::fromUtf8("label_2_1"));
        label_2_1->setGeometry(QRect(10, 10, 225, 20));
        label_2_2 = new QLabel(tab_2);
        label_2_2->setObjectName(QString::fromUtf8("label_2_2"));
        label_2_2->setGeometry(QRect(245, 10, 225, 20));
        label_2_3 = new QLabel(tab_2);
        label_2_3->setObjectName(QString::fromUtf8("label_2_3"));
        label_2_3->setGeometry(QRect(10, 80, 460, 20));
        label_2_3->setTextFormat(Qt::AutoText);
        comboBox_2_1 = new QComboBox(tab_2);
        comboBox_2_1->setObjectName(QString::fromUtf8("comboBox_2_1"));
        comboBox_2_1->setGeometry(QRect(10, 40, 225, 30));
        comboBox_2_1->setEditable(true);
        comboBox_2_2 = new QComboBox(tab_2);
        comboBox_2_2->setObjectName(QString::fromUtf8("comboBox_2_2"));
        comboBox_2_2->setGeometry(QRect(245, 40, 225, 30));
        comboBox_2_2->setEditable(true);
        textBrowser_2_2 = new QTextBrowser(tab_2);
        textBrowser_2_2->setObjectName(QString::fromUtf8("textBrowser_2_2"));
        textBrowser_2_2->setGeometry(QRect(10, 320, 460, 130));
        textBrowser_2_2->setReadOnly(false);
        textBrowser_2_2->setAcceptRichText(false);
        textBrowser_2_3 = new QTextBrowser(tab_2);
        textBrowser_2_3->setObjectName(QString::fromUtf8("textBrowser_2_3"));
        textBrowser_2_3->setGeometry(QRect(10, 490, 460, 130));
        textBrowser_2_3->setReadOnly(false);
        textBrowser_2_3->setAcceptRichText(false);
        label_2_4 = new QLabel(tab_2);
        label_2_4->setObjectName(QString::fromUtf8("label_2_4"));
        label_2_4->setGeometry(QRect(10, 220, 460, 20));
        label_2_5 = new QLabel(tab_2);
        label_2_5->setObjectName(QString::fromUtf8("label_2_5"));
        label_2_5->setGeometry(QRect(10, 290, 460, 20));
        label_2_6 = new QLabel(tab_2);
        label_2_6->setObjectName(QString::fromUtf8("label_2_6"));
        label_2_6->setGeometry(QRect(10, 460, 460, 20));
        comboBox_2_3 = new QComboBox(tab_2);
        comboBox_2_3->setObjectName(QString::fromUtf8("comboBox_2_3"));
        comboBox_2_3->setGeometry(QRect(10, 250, 460, 30));
        comboBox_2_3->setEditable(true);
        pushButton_2_1 = new QPushButton(tab_2);
        pushButton_2_1->setObjectName(QString::fromUtf8("pushButton_2_1"));
        pushButton_2_1->setGeometry(QRect(140, 630, 200, 30));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        label_3_1 = new QLabel(tab_3);
        label_3_1->setObjectName(QString::fromUtf8("label_3_1"));
        label_3_1->setGeometry(QRect(0, 0, 220, 100));
        label_3_1->setTextFormat(Qt::AutoText);
        label_3_1->setPixmap(QPixmap(QString::fromUtf8(":/icons/cany_standby.png")));
        tabWidget->addTab(tab_3, QString());

        retranslateUi(gui_cany);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(gui_cany);
    } // setupUi

    void retranslateUi(QDialog *gui_cany)
    {
        gui_cany->setWindowTitle(QApplication::translate("gui_cany", "Cany", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_1), QApplication::translate("gui_cany", "Consultar", nullptr));
        label_2_1->setText(QApplication::translate("gui_cany", "Linguagem", nullptr));
        label_2_2->setText(QApplication::translate("gui_cany", "Biblioteca", nullptr));
        label_2_3->setText(QApplication::translate("gui_cany", "Descri\303\247\303\243o da Biblioteca", nullptr));
        label_2_4->setText(QApplication::translate("gui_cany", "Fun\303\247\303\243o", nullptr));
        label_2_5->setText(QApplication::translate("gui_cany", "Descri\303\247\303\243o do Fun\303\247\303\243o", nullptr));
        label_2_6->setText(QApplication::translate("gui_cany", "Exemplo", nullptr));
        pushButton_2_1->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("gui_cany", "Registrar/Editar", nullptr));
        label_3_1->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("gui_cany", "StandBy", nullptr));
    } // retranslateUi

};

namespace Ui {
    class gui_cany: public Ui_gui_cany {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_CANY_H
