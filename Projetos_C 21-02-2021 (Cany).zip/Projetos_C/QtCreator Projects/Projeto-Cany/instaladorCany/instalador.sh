sudo mv Cany /usr/local
cd /usr/local/Cany
sudo mv cany /usr/local/bin
sudo mv Cany.desktop /usr/share/applications
cd
mv /usr/local/Cany/.cany_db .cany_db
echo "O Aplicativo Cany foi instalado com sucesso!"
echo "pressione qualquer tecla para finalizar"
read esc
cd
sudo rm -r instaladorCany
