/*
 * File:   main.cpp
 * Author: Bruno Santos
 *
 * Created on 17 de Fevereiro de 2021
 */

#include "gui_cany.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    gui_cany w;
    w.show();
    return a.exec();
}
