/*
 * File:   gui_cany.h
 * Author: Bruno Santos
 *
 * Created on 17 de Fevereiro de 2021
 */

#ifndef GUI_CANY_H
#define GUI_CANY_H

#include <QDialog>

QT_BEGIN_NAMESPACE
namespace Ui { class gui_cany; }
QT_END_NAMESPACE

class gui_cany : public QDialog
{
    Q_OBJECT

public:
    gui_cany(QDialog *parent = nullptr);
    ~gui_cany();
    public slots:
        void seletorLinguagemConsulta();
        void seletorBibliotecaConsulta();
        void seletorFuncaoConsulta();
        char *tratamentoRegistro(QString entrada);
        void alocaAreaTransferencia(int seletor, int tamanho);
        void alocaCopiaAreaTransferencia(int seletor, QString entrada);
        void tabWidget_currentChanged(int index );
        void comboBox_1_1_currentIndexChanged();
        void comboBox_1_2_currentIndexChanged();
        void comboBox_1_3_currentIndexChanged();
        void pushButton_2_1_released();
        void comboBox_2_1_highlighted();
        void comboBox_2_2_highlighted();
        void comboBox_2_3_highlighted();
        void comboBox_2_1_currentTextChanged();
        void comboBox_2_2_currentTextChanged();
        void comboBox_2_3_currentTextChanged();
        void comboBox_2_1_currentIndexChanged(const QString &item);
        void comboBox_2_2_currentIndexChanged(const QString &item);
        void comboBox_2_3_currentIndexChanged(const QString &item);
        void textBrowser_2_1_textChanged();
        void textBrowser_2_2_textChanged();
        void textBrowser_2_3_textChanged();
        void enterEvent(QEvent *event);
private:
    Ui::gui_cany *ui;
};
#endif // GUI_CANY_H
