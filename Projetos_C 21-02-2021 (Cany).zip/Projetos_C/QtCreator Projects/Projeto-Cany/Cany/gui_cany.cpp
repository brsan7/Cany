/*
 * File:   gui_cany.cpp
 * Author: Bruno Santos
 *
 * Created on 17 de Fevereiro de 2021
 */

#include "gui_cany.h"
#include "./ui_gui_cany.h"
#include <QtSql>

/*variaveis globais*/
QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
QSqlQuery query;
bool flagVerificarDescLib=false;
bool flagVerificarDescFcn=false;
bool flagVerificarExemplo=false;
bool flagConsultarLinguagem=true;
bool flagConsultarBiblioteca=false;
bool flagConsultarFuncao=false;
bool flagRegistrarLinguagem=false;
bool flagRegistrarBiblioteca=false;
bool flagRegistrarFuncao=false;
bool flagEditarDescricaoLib=false;
bool flagEditarDescricaoFcn=false;
bool flagEditarExemplo=false;
bool flagApagar=false;
bool flagRegistrado=false;
int indexCB=0;
char *areaTransferencia1=nullptr;
char *areaTransferencia2=nullptr;
char *areaTransferencia3=nullptr;
char *areaTransferencia4=nullptr;
char *areaTransferencia5=nullptr;
unsigned int sizeAreaTransf=0;

//////////////////////////////////////
/*Inicio# Setup inicial da Interface*/
//////////////////////////////////////

gui_cany::gui_cany(QDialog *parent)
    : QDialog (parent)
    , ui(new Ui::gui_cany)
{
    ui->setupUi(this);
    connect(ui->tabWidget,SIGNAL(currentChanged(int)),this,SLOT(tabWidget_currentChanged(int)));
    connect(ui->comboBox_1_1,SIGNAL(currentIndexChanged(int)),this,SLOT(comboBox_1_1_currentIndexChanged()));
    connect(ui->comboBox_1_2,SIGNAL(currentIndexChanged(int)),this,SLOT(comboBox_1_2_currentIndexChanged()));
    connect(ui->comboBox_1_3,SIGNAL(currentIndexChanged(int)),this,SLOT(comboBox_1_3_currentIndexChanged()));
    connect(ui->pushButton_2_1,SIGNAL(released()),this,SLOT(pushButton_2_1_released()));
    connect(ui->comboBox_2_1,SIGNAL(highlighted(int)),this,SLOT(comboBox_2_1_highlighted()));
    connect(ui->comboBox_2_2,SIGNAL(highlighted(int)),this,SLOT(comboBox_2_2_highlighted()));
    connect(ui->comboBox_2_3,SIGNAL(highlighted(int)),this,SLOT(comboBox_2_3_highlighted()));
    connect(ui->comboBox_2_1,SIGNAL(currentTextChanged(const QString)),this,SLOT(comboBox_2_1_currentTextChanged()));
    connect(ui->comboBox_2_2,SIGNAL(currentTextChanged(const QString)),this,SLOT(comboBox_2_2_currentTextChanged()));
    connect(ui->comboBox_2_3,SIGNAL(currentTextChanged(const QString)),this,SLOT(comboBox_2_3_currentTextChanged()));
    connect(ui->comboBox_2_1,SIGNAL(currentIndexChanged(const QString)),this,SLOT(comboBox_2_1_currentIndexChanged(const QString)));
    connect(ui->comboBox_2_2,SIGNAL(currentIndexChanged(const QString)),this,SLOT(comboBox_2_2_currentIndexChanged(const QString)));
    connect(ui->comboBox_2_3,SIGNAL(currentIndexChanged(const QString)),this,SLOT(comboBox_2_3_currentIndexChanged(const QString)));
    connect(ui->textBrowser_2_1,SIGNAL(textChanged()),this,SLOT(textBrowser_2_1_textChanged()));
    connect(ui->textBrowser_2_2,SIGNAL(textChanged()),this,SLOT(textBrowser_2_2_textChanged()));
    connect(ui->textBrowser_2_3,SIGNAL(textChanged()),this,SLOT(textBrowser_2_3_textChanged()));
    /*inicializa SQLITE driver*/
    db.setDatabaseName(".cany_db");
    if (db.open()) {
        /*tenta localizar a tabela raiz "canivetes".
          Se não existir, um novo banco de dados será criado.*/
        if (db.tables().indexOf("canivetes") == -1) {
            QSqlQuery query(db);
            query.prepare("CREATE TABLE canivetes ("
                          "biblioteca VARCHAR(20), "
                          "linguagem VARCHAR(20), "
                          "descricao_lib VARCHAR(500),"
                          "PRIMARY KEY (biblioteca))");
            if (!query.exec()){qCritical() << query.lastError();}
            query.prepare("CREATE TABLE ferramentas ("
                          "funcao VARCHAR(100), "
                          "biblioteca VARCHAR(20) REFERENCES canivetes(biblioteca),"
                          "descricao_fcn VARCHAR(500), "
                          "exemplo VARCHAR(1000),"
                          "PRIMARY KEY (funcao))");
            if (!query.exec()){qCritical() << query.lastError();}
        }
    }
    else {qCritical() << db.lastError();}
    move(965,0);
    QFont fontConsulta("Helvetica", 14, QFont::Thin);
    ui->textBrowser_1_1->setFont(fontConsulta);
    seletorLinguagemConsulta();
}

///////////////////////////////////
/*Fim# Setup inicial da Interface*/
///////////////////////////////////
////////////////////////////////////////////////
/*Inicio# Inicializando abas TabWidget => Main*/
////////////////////////////////////////////////

void gui_cany::tabWidget_currentChanged ( int index ){
    //re-inicializa todos os componentes se não estiver em StandBy
    if(index!=2&&ui->tabWidget->tabPosition()==0){
        flagApagar=false;
        flagEditarDescricaoLib=false;
        flagEditarDescricaoFcn=false;
        flagEditarExemplo=false;
        flagVerificarDescLib=false;
        flagVerificarExemplo=false;
        flagVerificarDescFcn=false;
        flagRegistrarBiblioteca=false;
        flagRegistrarLinguagem=false;
        flagRegistrarFuncao=false;
        ui->textBrowser_2_1->setReadOnly(false);
        ui->textBrowser_2_1->clear();
        ui->textBrowser_2_2->clear();
        ui->textBrowser_2_3->clear();
        ui->comboBox_2_1->clear();
        ui->comboBox_2_2->clear();
        ui->comboBox_2_3->clear();
        ui->label_2_3->setText("Descrição da Biblioteca");
        ui->label_2_5->setText("Descrição da Função");
        ui->label_2_6->setText("Exemplo");
        ui->pushButton_2_1->setText("");
        ui->pushButton_2_1->setDisabled(true);
    }

    /*aba de consulta*/
    if(index==0&&ui->tabWidget->tabPosition()!=0){
        ui->tabWidget->setTabPosition(QTabWidget::North);}

    /*aba de registro/edição*/
    if(index==1){
        //inicia o seletor de linguagem
        ui->comboBox_2_1->insertItem(0,"Linguagens");
        ui->comboBox_2_2->insertItem(0,"");
        ui->comboBox_2_3->insertItem(0,"");
        query.exec("SELECT linguagem FROM canivetes GROUP BY linguagem ORDER BY linguagem");
        indexCB=1;
        //popula o componente com as linguagens registradas
        while(query.next()){
            ui->comboBox_2_1->insertItem(indexCB,query.value(0).toString().toUtf8());
            indexCB++;
        }
    }
    if(index==2){resize(204,104);move(1170,0);ui->tabWidget->setTabPosition(QTabWidget::South);}
}

/////////////////////////////////////////////
/*Fim# Inicializando abas TabWidget => Main*/
/////////////////////////////////////////////
/////////////////////////////////////
/*Inicio# Eventos Tab_1 => Consulta*/
/////////////////////////////////////

/*tela inicial do seletor de linguagens*/
void gui_cany::seletorLinguagemConsulta(){
    if(flagConsultarLinguagem){
        ui->textBrowser_1_1->clear();
        ui->comboBox_1_2->clear();
        ui->comboBox_1_3->clear();
        ui->textBrowser_1_1->setText("========================================");
        ui->textBrowser_1_1->append("            Cany - Canivete universal de consulta           ");
        ui->textBrowser_1_1->append("========================================");
        ui->textBrowser_1_1->setFontUnderline(true);
        ui->textBrowser_1_1->append("Linguagens Registradas");
        ui->textBrowser_1_1->setFontUnderline(false);

        query.exec("SELECT linguagem FROM canivetes GROUP BY linguagem ORDER BY linguagem");
        //popula o componente com as linguagens registradas
        indexCB=1;
        if(strcmp(ui->comboBox_1_1->currentText().toUtf8(),"Linguagens")!=0){
            ui->comboBox_1_1->insertItem(0,"Linguagens");
        }else{indexCB=0;}
        while(query.next()){
            if(indexCB>0){
                ui->comboBox_1_1->insertItem(indexCB,query.value(0).toString().toUtf8());
                indexCB++;
            }
            ui->textBrowser_1_1->append(query.value(0).toString().toUtf8());
        }
        ui->textBrowser_1_1->scrollToAnchor("=");
        //seta o controle de fluxo da consulta
        flagConsultarLinguagem=false;
        flagConsultarBiblioteca=true;
        flagConsultarFuncao=false;
        flagRegistrado=false;
    }
}

/*tela inicial do seletor de bibliotecas*/
void gui_cany::seletorBibliotecaConsulta(){
    if(flagConsultarBiblioteca){
        ui->textBrowser_1_1->clear();
        ui->comboBox_1_3->clear();
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_1->currentText()));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+77);
        sprintf(areaTransferencia2,"Bibliotecas [%s]",areaTransferencia1);
        ui->textBrowser_1_1->setText(areaTransferencia2);
        ui->textBrowser_1_1->append("========================================");
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_1->currentText()));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"SELECT biblioteca, descricao_lib "
                                   "FROM canivetes "
                                   "WHERE linguagem = '%s' ORDER BY biblioteca",areaTransferencia1);
        query.exec(areaTransferencia2);
        //popula o componente com as bibliotecas da linguagem selecionada
        indexCB=1;
        if(strcmp(ui->comboBox_1_2->currentText().toUtf8(),"Bibliotecas")!=0){
            ui->comboBox_1_2->insertItem(indexCB,"Bibliotecas");
        }else{indexCB=0;}
        while(query.next()){
            if(indexCB>0){
                ui->comboBox_1_2->insertItem(indexCB,query.value(0).toString().toUtf8());
                indexCB++;
            }
            ui->textBrowser_1_1->setFontUnderline(true);
            ui->textBrowser_1_1->append(query.value(0).toString().toUtf8());
            ui->textBrowser_1_1->setFontUnderline(false);
            ui->textBrowser_1_1->append(query.value(1).toString().toUtf8());
            ui->textBrowser_1_1->append("__________________________________________");
        }
        //seta o controle de fluxo da consulta
        ui->textBrowser_1_1->scrollToAnchor("=");
        flagConsultarLinguagem=true;
        flagConsultarBiblioteca=false;
        flagConsultarFuncao=true;
    }
}

/*tela inicial do seletor de bibliotecas*/
void gui_cany::seletorFuncaoConsulta(){
    if(flagConsultarFuncao){
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_2->currentText()));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"Funções [%s][",areaTransferencia1);
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_1->currentText()));
        strcat(areaTransferencia2,areaTransferencia1);strcat(areaTransferencia2,"]");
        ui->textBrowser_1_1->setText(areaTransferencia2);
        ui->textBrowser_1_1->append("========================================");
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_2->currentText()));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"SELECT funcao, descricao_fcn "
                                   "FROM ferramentas "
                                   "WHERE biblioteca = '%s' ORDER BY funcao",areaTransferencia1);
        query.exec(areaTransferencia2);
        indexCB=1;
        if(strcmp(ui->comboBox_1_3->currentText().toUtf8(),"Funções")!=0){
            ui->comboBox_1_3->insertItem(indexCB,"Funções");
        }else{indexCB=0;}
        while(query.next()){
            if(indexCB>0){
                ui->comboBox_1_3->insertItem(indexCB,query.value(0).toString().toUtf8());
                indexCB++;
            }
            ui->textBrowser_1_1->setFontUnderline(true);
            ui->textBrowser_1_1->append(query.value(0).toString().toUtf8());
            ui->textBrowser_1_1->setFontUnderline(false);
            ui->textBrowser_1_1->append(query.value(1).toString().toUtf8());
            ui->textBrowser_1_1->append("__________________________________________");
        }
        ui->textBrowser_1_1->scrollToAnchor("=");
        //seta o controle de fluxo da consulta
        flagConsultarBiblioteca=true;
        flagConsultarFuncao=false;
    }
}

/*campo seletor de linguagens para consulta*/
void gui_cany::comboBox_1_1_currentIndexChanged(){
    ui->comboBox_1_2->clear();
    ui->comboBox_1_3->clear();
    if(ui->comboBox_1_1->currentIndex()>0){
        flagConsultarLinguagem=false;
        flagConsultarBiblioteca=true;
        flagConsultarFuncao=false;
        seletorBibliotecaConsulta();
    }
    else{if(flagConsultarBiblioteca||flagConsultarFuncao){seletorLinguagemConsulta();}}
}

/*campo seletor de bibliotecas para consulta*/
void gui_cany::comboBox_1_2_currentIndexChanged(){
    ui->comboBox_1_3->clear();
    if(ui->comboBox_1_2->currentIndex()>0){
        flagConsultarFuncao=true;
        seletorFuncaoConsulta();
    }
    else{if(flagConsultarLinguagem||flagConsultarFuncao){seletorBibliotecaConsulta();}}
}

/*campo seletor de funções para consulta*/
void gui_cany::comboBox_1_3_currentIndexChanged(){
    if(ui->comboBox_1_3->currentIndex()>0){
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_3->currentText()));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"%s [",areaTransferencia1);
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_2->currentText()));
        strcat(areaTransferencia2,areaTransferencia1);strcat(areaTransferencia2,"][");
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_1->currentText()));
        strcat(areaTransferencia2,areaTransferencia1);strcat(areaTransferencia2,"]");
        ui->textBrowser_1_1->setText(areaTransferencia2);
        ui->textBrowser_1_1->append("=======================================");
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_1_3->currentText()));
        sprintf(areaTransferencia2,"SELECT descricao_fcn, exemplo "
                                   "FROM ferramentas "
                                   "WHERE funcao = '%s'",areaTransferencia1);
        query.exec(areaTransferencia2);
        while(query.next()){
            ui->textBrowser_1_1->append(query.value(0).toString().toUtf8());
            ui->textBrowser_1_1->append("_________________________________________");
            ui->textBrowser_1_1->append(query.value(1).toString().toUtf8());
            indexCB++;
        }
        ui->textBrowser_1_1->scrollToAnchor("=");
    }
    else {
        if(!flagConsultarFuncao
                &&ui->comboBox_1_1->currentIndex()>0&&ui->comboBox_1_2->currentIndex()>0){

            flagConsultarFuncao=true;
            seletorFuncaoConsulta();
        }
    }
}
//////////////////////////////////
/*Fim# Eventos Tab_1 => Consulta*/
//////////////////////////////////
////////////////////////////////////////////
/*Inicio# Eventos Tab_2 => Registro/Edição*/
////////////////////////////////////////////

/*verifica se um registro do banco de dados foi alterado*/
void gui_cany::textBrowser_2_1_textChanged(){
    if(ui->comboBox_2_1->currentIndex()>0&&ui->comboBox_2_2->currentIndex()>0&&!flagEditarDescricaoLib
            &&!flagRegistrarLinguagem&&!flagRegistrarBiblioteca&&!flagRegistrarFuncao){

        if(strcmp(areaTransferencia4,ui->textBrowser_2_1->document()->toPlainText().toUtf8())!=0&&flagVerificarDescLib){
            ui->pushButton_2_1->setText("Editar");
            ui->pushButton_2_1->setEnabled(true);
            ui->label_2_3->setText("<b style=color:red>Descrição da Biblioteca(EDITADO)<b>");
            flagEditarDescricaoLib=true;
            flagApagar=false;
            flagRegistrarLinguagem=false;
            flagRegistrarBiblioteca=false;
            flagRegistrarFuncao=false;
        }else{
            flagVerificarDescLib=true;
            alocaCopiaAreaTransferencia(4,ui->textBrowser_2_1->document()->toPlainText().toUtf8());
        }
    }
}
/*verifica se um registro do banco de dados foi alterado*/
void gui_cany::textBrowser_2_2_textChanged(){
    if(ui->comboBox_2_1->currentIndex()>0&&ui->comboBox_2_2->currentIndex()>0
            &&ui->comboBox_2_3->currentIndex()>0&&!flagEditarDescricaoFcn
            &&!flagRegistrarLinguagem&&!flagRegistrarBiblioteca&&!flagRegistrarFuncao){

        if(strcmp(areaTransferencia4,ui->textBrowser_2_2->document()->toPlainText().toUtf8())!=0&&flagVerificarDescFcn){
            ui->pushButton_2_1->setText("Editar");
            ui->pushButton_2_1->setEnabled(true);
            ui->label_2_5->setText("<b style=color:red>Descrição da Função(EDITADO)<b>");
            flagEditarDescricaoFcn=true;
            flagApagar=false;
            flagRegistrarLinguagem=false;
            flagRegistrarBiblioteca=false;
            flagRegistrarFuncao=false;
        }else{
            flagVerificarDescFcn=true;
            alocaCopiaAreaTransferencia(1,ui->textBrowser_2_1->document()->toPlainText().toUtf8());
        }
    }
}
/*verifica se um registro do banco de dados foi alterado*/
void gui_cany::textBrowser_2_3_textChanged(){
    if(ui->comboBox_2_1->currentIndex()>0&&ui->comboBox_2_2->currentIndex()>0
            &&ui->comboBox_2_3->currentIndex()>0&&!flagEditarExemplo
            &&!flagRegistrarLinguagem&&!flagRegistrarBiblioteca&&!flagRegistrarFuncao){

        if(strcmp(areaTransferencia2,ui->textBrowser_2_3->document()->toPlainText().toUtf8())!=0&&flagVerificarExemplo){
            ui->pushButton_2_1->setText("Editar");
            ui->pushButton_2_1->setEnabled(true);
            ui->label_2_6->setText("<b style=color:red>Exemplo(EDITADO)<b>");
            flagEditarExemplo=true;
            flagApagar=false;
            flagRegistrarLinguagem=false;
            flagRegistrarBiblioteca=false;
            flagRegistrarFuncao=false;
        }else{
            flagVerificarExemplo=true;
            alocaCopiaAreaTransferencia(2,ui->textBrowser_2_1->document()->toPlainText().toUtf8());
        }
    }
}

/*Sinaliza o os campos para novos registros*/
void gui_cany::comboBox_2_1_highlighted(){
    ui->comboBox_2_1->setItemText(0,"*NOVO");

}
void gui_cany::comboBox_2_2_highlighted(){
    ui->comboBox_2_2->setItemText(0,"*NOVO");
}
void gui_cany::comboBox_2_3_highlighted(){
    if(!flagEditarDescricaoLib){
        ui->comboBox_2_3->setItemText(0,"*NOVO");
    }else{
        ui->comboBox_2_3->setItemText(0,"EDITAR FUNÇÃO");
        ui->comboBox_2_3->setEditable(false);
    }
}

/*habilita o botão para registro de nova linguagem, biblioteca(chave primária) e função(chave estrangeira)*/
void gui_cany::comboBox_2_1_currentTextChanged(){
    if(ui->comboBox_2_1->currentIndex()==0&&!flagRegistrado
            &&strcmp(ui->comboBox_2_1->currentText().toUtf8(),"Linguagens")!=0
            &&strcmp(ui->comboBox_2_1->currentText().toUtf8(),"*NOVO")!=0){

        ui->comboBox_2_1->clear();
        ui->comboBox_2_2->insertItem(0,"*NOVO");
        ui->comboBox_2_3->insertItem(0,"*NOVO");
        ui->textBrowser_2_1->setText("*NOVO");
        ui->textBrowser_2_2->setText("*NOVO");
        ui->textBrowser_2_3->setText("*NOVO");
        flagRegistrarLinguagem=true;
        flagApagar=false;
    }
}

/*habilita o botão para registro de nova biblioteca(chave primária)*/
void gui_cany::comboBox_2_2_currentTextChanged(){
    if(ui->comboBox_2_2->currentIndex()==0&&!flagRegistrado
            &&(ui->comboBox_2_1->currentIndex()>0||flagRegistrarLinguagem)
            &&strcmp(ui->comboBox_2_2->currentText().toUtf8(),"Bibliotecas")!=0
            &&strcmp(ui->comboBox_2_2->currentText().toUtf8(),"*NOVO")!=0){

        ui->comboBox_2_2->clear();
        ui->textBrowser_2_1->setText("*NOVO");
        ui->textBrowser_2_2->setText("*NOVO");
        ui->textBrowser_2_3->setText("*NOVO");
        ui->comboBox_2_3->clear();
        ui->comboBox_2_3->insertItem(0,"*NOVO");
        ui->pushButton_2_1->setText("Registrar");
        ui->pushButton_2_1->setEnabled(true);
        flagRegistrarBiblioteca=true;
        flagApagar=false;
    }
}

/*habilita o botão para registro de nova função(chave estrangeira)*/
void gui_cany::comboBox_2_3_currentTextChanged(){
    if(ui->comboBox_2_3->currentIndex()==0&&!flagEditarDescricaoLib&&!flagRegistrado
            &&(ui->comboBox_2_1->currentIndex()>0||flagRegistrarLinguagem)
            &&strcmp(ui->comboBox_2_3->currentText().toUtf8(),"Funções")!=0
            &&strcmp(ui->comboBox_2_3->currentText().toUtf8(),"*NOVO")!=0){

        ui->comboBox_2_3->clear();
        ui->textBrowser_2_1->setReadOnly(true);
        ui->textBrowser_2_2->setText("*NOVO");
        ui->textBrowser_2_3->setText("*NOVO");
        ui->pushButton_2_1->setText("Registrar");
        ui->pushButton_2_1->setEnabled(true);
        flagRegistrarFuncao=true;
        flagApagar=false;
    }
}

/*campo seletor de linguagens  da interface de registro/modificação*/
void gui_cany::comboBox_2_1_currentIndexChanged(const QString &item){
    ui->comboBox_2_2->clear();
    ui->comboBox_2_3->clear();
    ui->textBrowser_2_1->setReadOnly(false);
    ui->textBrowser_2_1->clear();
    ui->textBrowser_2_2->clear();
    ui->textBrowser_2_3->clear();
    ui->label_2_3->setText("Descrição da Biblioteca");
    ui->label_2_5->setText("Descrição da Função");
    ui->label_2_6->setText("Exemplo");
    ui->pushButton_2_1->setText("");
    ui->pushButton_2_1->setDisabled(true);
    flagEditarDescricaoLib=false;
    flagEditarDescricaoFcn=false;
    flagEditarExemplo=false;
    flagVerificarDescLib=false;
    flagVerificarDescFcn=false;
    flagVerificarExemplo=false;
    if(ui->comboBox_2_1->currentIndex()>0&&!flagRegistrado){
        //inicia o seletor de bibliotecas
        ui->comboBox_2_1->setEditable(false);
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(item));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        ui->comboBox_2_2->insertItem(0,"Bibliotecas");
        //seleciona as bibliotecas registrados na linguagem selecionada para popular o componente
        sprintf(areaTransferencia2,"SELECT biblioteca "
                                   "FROM canivetes "
                                   "WHERE linguagem = '%s' ORDER BY biblioteca",areaTransferencia1);
        query.exec(areaTransferencia2);
        indexCB=1;
        //popula o componente com as bibliotecas registradas
        while(query.next()){
            ui->comboBox_2_2->insertItem(indexCB,query.value(0).toString().toUtf8());
            indexCB++;
        }
    }else{ui->comboBox_2_1->setEditable(true);}
}

/*campo seletor de bibliotecas da interface de registro/modificação*/
void gui_cany::comboBox_2_2_currentIndexChanged(const QString &item){
    ui->label_2_3->setText("Descrição da Biblioteca");
    ui->label_2_5->setText("Descrição da Função");
    ui->label_2_6->setText("Exemplo");
    ui->textBrowser_2_1->setReadOnly(false);
    ui->pushButton_2_1->setText("");
    ui->pushButton_2_1->setDisabled(true);
    flagEditarDescricaoLib=false;
    flagEditarDescricaoFcn=false;
    flagEditarExemplo=false;
    flagVerificarDescLib=false;
    flagVerificarDescFcn=false;
    flagVerificarExemplo=false;
    if(ui->comboBox_2_2->currentIndex()>0&&!flagRegistrado
            &&ui->comboBox_2_1->currentIndex()>0){
        //inicia o seletor de funcaos
        ui->comboBox_2_3->clear();
        ui->textBrowser_2_2->clear();
        ui->textBrowser_2_3->clear();
        ui->comboBox_2_2->setEditable(false);
        //popula o componente com a descrição da biblioteca selecionada
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(item));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"SELECT descricao_lib "
                                   "FROM canivetes "
                                   "WHERE biblioteca = '%s'",areaTransferencia1);
        query.exec(areaTransferencia2);query.next();
        ui->textBrowser_2_1->setText(query.value(0).toString().toUtf8());
        //popula o componente com as funções registrados para a biblioteca selecionada
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"SELECT funcao "
                                   "FROM ferramentas "
                                   "WHERE biblioteca = '%s' ORDER BY funcao",areaTransferencia1);
        query.exec(areaTransferencia2);
        ui->comboBox_2_3->insertItem(0,"Funções");
        indexCB=1;
        //popula o componente com as funções registradas para a biblioteca selecionada
        while(query.next()){
            ui->comboBox_2_3->insertItem(indexCB,query.value(0).toString().toUtf8());
            indexCB++;
        }
        if(!flagEditarDescricaoLib&&indexCB==1){
            ui->pushButton_2_1->setText("Apagar");
            ui->pushButton_2_1->setEnabled(true);
            flagApagar=true;
        }
    }else{ui->comboBox_2_2->setEditable(true);}
}

/*campo seletor de funções da interface de registro/modificação*/
void gui_cany::comboBox_2_3_currentIndexChanged(const QString &item){
    ui->label_2_5->setText("Descrição da Função");
    ui->label_2_6->setText("Exemplo");
    flagEditarDescricaoFcn=false;
    flagEditarExemplo=false;
    flagVerificarDescFcn=false;
    flagVerificarExemplo=false;
    if(ui->comboBox_2_3->currentIndex()>0&&!flagRegistrado){

        ui->comboBox_2_3->setEditable(false);
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(item));
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"SELECT descricao_fcn, exemplo "
                                   "FROM ferramentas "
                                   "WHERE funcao = '%s'",areaTransferencia1);
        query.exec(areaTransferencia2);query.next();
        ui->textBrowser_2_2->setText(query.value(0).toString().toUtf8());
        ui->textBrowser_2_3->setText(query.value(1).toString().toUtf8());
        if(!flagEditarDescricaoFcn&&!flagEditarExemplo){
            ui->pushButton_2_1->setText("Apagar");
            ui->pushButton_2_1->setEnabled(true);
            flagApagar=true;
        }
    }else{
        if(flagEditarDescricaoLib){
            ui->textBrowser_2_2->clear();
            ui->textBrowser_2_3->clear();
            ui->comboBox_2_3->setItemText(0,"EDITAR FUNÇÃO");
            ui->comboBox_2_3->setEditable(false);
        }else{
            ui->pushButton_2_1->setText("");
            ui->pushButton_2_1->setDisabled(true);
            ui->comboBox_2_3->setEditable(true);
        }
    }
}

/*botão multifunção para submeter novo registro, modificar ou apagar*/
void gui_cany::pushButton_2_1_released(){
    //registra uma nova biblioteca e(ou) linguagem na tabela canivetes
    if(flagRegistrarLinguagem||flagRegistrarBiblioteca){
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_2_2->currentText()));
        alocaCopiaAreaTransferencia(2,tratamentoRegistro(ui->comboBox_2_1->currentText()));
        alocaCopiaAreaTransferencia(3,tratamentoRegistro(ui->textBrowser_2_1->document()->toPlainText()));
        alocaAreaTransferencia(5,strlen(areaTransferencia1)
                                +strlen(areaTransferencia2)
                                +strlen(areaTransferencia3)+100);
        sprintf(areaTransferencia5,"INSERT INTO canivetes VALUES('%s' ,'%s' ,'%s')",
                areaTransferencia1,areaTransferencia2,areaTransferencia3);
        query.exec(areaTransferencia5);
    }
    //registra uma nova função na tabela ferramentas
    if(flagRegistrarBiblioteca||flagRegistrarFuncao){
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_2_3->currentText()));
        alocaCopiaAreaTransferencia(2,tratamentoRegistro(ui->comboBox_2_2->currentText()));
        alocaCopiaAreaTransferencia(3,tratamentoRegistro(ui->textBrowser_2_2->document()->toPlainText()));
        alocaCopiaAreaTransferencia(4,tratamentoRegistro(ui->textBrowser_2_3->document()->toPlainText()));
        alocaAreaTransferencia(5,strlen(areaTransferencia1)
                                +strlen(areaTransferencia2)
                                +strlen(areaTransferencia3)
                                +strlen(areaTransferencia4)+100);
        sprintf(areaTransferencia5,"INSERT INTO ferramentas VALUES('%s' ,'%s' ,'%s' ,'%s')",
                areaTransferencia1,areaTransferencia2,areaTransferencia3,areaTransferencia4);
        query.exec(areaTransferencia5);
    }
    //modifica o campo de descrição da tabela canivetes
    if(flagEditarDescricaoLib){
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->textBrowser_2_1->document()->toPlainText()));
        alocaCopiaAreaTransferencia(2,tratamentoRegistro(ui->comboBox_2_2->currentText()));
        alocaAreaTransferencia(5,strlen(areaTransferencia1)
                                +strlen(areaTransferencia2)+100);
        sprintf(areaTransferencia5,"UPDATE canivetes "
                                   "SET descricao_lib = '%s' "
                                   "WHERE biblioteca = '%s'",
                areaTransferencia1,areaTransferencia2);
        query.exec(areaTransferencia5);
    }
    //modifica o campo de descrição e exemplo da tabela ferramentas
    if(flagEditarDescricaoFcn||flagEditarExemplo){
        alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->textBrowser_2_2->document()->toPlainText()));
        alocaCopiaAreaTransferencia(2,tratamentoRegistro(ui->textBrowser_2_3->document()->toPlainText()));
        alocaCopiaAreaTransferencia(3,tratamentoRegistro(ui->comboBox_2_3->currentText()));
        alocaAreaTransferencia(5,strlen(areaTransferencia1)
                                +strlen(areaTransferencia2)
                                +strlen(areaTransferencia3)+100);
        sprintf(areaTransferencia5,"UPDATE ferramentas "
                                   "SET descricao_fcn = '%s' ,exemplo = '%s' "
                                   "WHERE funcao = '%s'",
                areaTransferencia1,areaTransferencia2,areaTransferencia3);
        query.exec(areaTransferencia5);
    }
    //deleta registros existentes
    if(flagApagar){
        //apaga uma a uma as funções registradas na tabela ferramentas
        //se não houver apenas uma funçõa para apagar, apaga a biblioteca da tabela canivetes
        alocaCopiaAreaTransferencia(1,ui->comboBox_2_2->currentText());
        alocaAreaTransferencia(2,strlen(areaTransferencia1)+100);
        sprintf(areaTransferencia2,"SELECT funcao "
                                   "FROM ferramentas "
                                   "WHERE biblioteca = '%s'",areaTransferencia1);
        query.exec(areaTransferencia2);
        indexCB=0;
        while(query.next()){
            indexCB++;
        }
        if(indexCB<=1){
            alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_2_2->currentText()));
            alocaAreaTransferencia(5,strlen(areaTransferencia1)+100);
            sprintf(areaTransferencia5,"DELETE FROM canivetes "
                                       "WHERE biblioteca = '%s'",areaTransferencia1);
            query.exec(areaTransferencia5);
        }
        else{
            alocaCopiaAreaTransferencia(1,tratamentoRegistro(ui->comboBox_2_3->currentText()));
            alocaAreaTransferencia(5,strlen(areaTransferencia1)+100);
            sprintf(areaTransferencia5,"DELETE FROM ferramentas "
                                       "WHERE funcao = '%s'",areaTransferencia1);
            query.exec(areaTransferencia5);
        }
    }
    flagRegistrado=true;
    flagConsultarLinguagem=true;
    flagConsultarBiblioteca=false;
    flagConsultarFuncao=false;
    flagRegistrarLinguagem=false;
    flagRegistrarBiblioteca=false;
    flagRegistrarFuncao=false;
    ui->textBrowser_1_1->clear();
    ui->comboBox_1_1->clear();
    ui->comboBox_1_2->clear();
    ui->comboBox_1_3->clear();
    seletorLinguagemConsulta();
    ui->tabWidget->setCurrentIndex(0);
}

/*acrescenta uma aspa simples ['] para cada aspa simples ['] encontrado
evitando assim comflito na sintaxe de registro SQL*/
char *gui_cany::tratamentoRegistro(QString entrada){
    unsigned long indexAddChar=0;
    char comparador[2]="\0";
    alocaCopiaAreaTransferencia(4,entrada);
    alocaCopiaAreaTransferencia(5,entrada);
    memset(areaTransferencia5,'\0',strlen(entrada.toUtf8())+100);
    while(indexAddChar<strlen(entrada.toUtf8())){

        strncpy(comparador,&areaTransferencia4[indexAddChar],1);
        if(strcmp(comparador,"'")==0){
            strcat(areaTransferencia5,"''");
        }
        else{
            strncat(areaTransferencia5,&areaTransferencia4[indexAddChar],1);
        }
        indexAddChar++;
    }
    return areaTransferencia5;
}

/////////////////////////////////////////
/*Fim# Eventos Tab_2 => Registro/Edição*/
/////////////////////////////////////////
///////////////////////////////////////////////////////////
/*Inicio# alocação de memória => Registro/Edição/Consulta*/
///////////////////////////////////////////////////////////

/*aloca memória nos ponteiros areaTransferencia para tratamento dos dados*/
void gui_cany::alocaAreaTransferencia(int seletor, int tamanho){
    switch (seletor) {
        case 1:{
            free(areaTransferencia1);areaTransferencia1=nullptr;
            if( (areaTransferencia1 = (char*)malloc(tamanho) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
          }
          break;
        case 2:{
            free(areaTransferencia2);areaTransferencia2=nullptr;
            if( (areaTransferencia2 = (char*)malloc(tamanho) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
          }
          break;
        case 5:{
            free(areaTransferencia5);areaTransferencia5=nullptr;
            if( (areaTransferencia5 = (char*)malloc(tamanho) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
          }
          break;
    }
}

/*aloca memória nos ponteiros areaTransferencia e carrega os dados a serem tratados*/
void gui_cany::alocaCopiaAreaTransferencia(int seletor, QString entrada){
    sizeAreaTransf=strlen(entrada.toUtf8());
    switch (seletor) {
        case 1:{
            free(areaTransferencia1);areaTransferencia1=nullptr;
            if( (areaTransferencia1 = (char*)malloc(sizeAreaTransf) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
            strcpy(areaTransferencia1,entrada.toUtf8());
          }
          break;
        case 2:{
            free(areaTransferencia2);areaTransferencia2=nullptr;
            if( (areaTransferencia2 = (char*)malloc(sizeAreaTransf) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
            strcpy(areaTransferencia2,entrada.toUtf8());
          }
          break;
        case 3:{
            free(areaTransferencia3);areaTransferencia3=nullptr;
            if( (areaTransferencia3 = (char*)malloc(sizeAreaTransf) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
            strcpy(areaTransferencia3,entrada.toUtf8());
          }
          break;
        case 4:{
            free(areaTransferencia4);areaTransferencia4=nullptr;
            if( (areaTransferencia4 = (char*)malloc(sizeAreaTransf) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
                strcpy(areaTransferencia4,entrada.toUtf8());
          }
          break;
        case 5:{
            free(areaTransferencia5);areaTransferencia5=nullptr;
            if( (areaTransferencia5 = (char*)malloc(sizeAreaTransf+100) )==NULL){
                printf("Erro de alocação - abortando.");
                exit(1);
            }
            strcpy(areaTransferencia5,entrada.toUtf8());
          }
          break;
    }
}

///////////////////////////////////////////////////////////
/*Fim# alocação de memória => Registro/Edição/Consulta*/
///////////////////////////////////////////////////////////
////////////////////////////////
/*Inicio# Eventos da Interface*/
////////////////////////////////

/*encerra o StandBy*/
void gui_cany::enterEvent(QEvent *event) {
    if(ui->tabWidget->currentIndex()==2){
        resize(480,700);move(965,0);
        ui->tabWidget->setCurrentIndex(0);
    }
}

gui_cany::~gui_cany()
{
    delete ui;
}
/////////////////////////////
/*Fim# Eventos da Interface*/
/////////////////////////////
